function arrayBufferToString(e) {
    return String.fromCharCode.apply(null, new Uint8Array(e))
}

function stringToArrayBuffer(e) {
    for (var t = new ArrayBuffer(e.length), n = new Uint8Array(t), r = 0, o = e.length; r < o; r += 1) n[r] = e.charCodeAt(r);
    return t
}

function r(e) {
    return btoa(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
}

function u() {
    return window.crypto.subtle.generateKey({
        name: "AES-GCM",
        length: 256
    }, !0, ["encrypt"])
}

function s(e, t, n, o) {
    var a = {
        name: "AES-GCM",
        iv: o,
        additionalData: stringToArrayBuffer(r(JSON.stringify(n))),
        tagLength: 128
    };
    return window.crypto.subtle.encrypt(a, t, stringToArrayBuffer(JSON.stringify(e))).then(function(e) {
        return [e, t]
    })
}

var l = function() {
    function e(e, t) {
        var n = [],
            r = !0,
            o = !1,
            a = void 0;
        try {
            for (var i, u = e[Symbol.iterator](); !(r = (i = u.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
        } catch (e) {
            o = !0, a = e
        } finally {
            try {
                !r && u.return && u.return()
            } finally {
                if (o) throw a
            }
        }
        return n
    }
    return function(t, n) {
        if (Array.isArray(t)) return t;
        if (Symbol.iterator in Object(t)) return e(t, n);
        throw new TypeError("Invalid attempt to destructure non-iterable instance")
    }
}();

function o(e) {
    var t = e;
    var h = {
        name: "RSA-OAEP",
        hash: {
            name: "SHA-1"
        }
    }
    return /Edge/.test(window.navigator.userAgent) && delete t.use, window.crypto.subtle.importKey("jwk", t, h, !1, ["wrapKey"])
}

function a(e, t) {
    return o(t).then(function(t) {
        return window.crypto.subtle.wrapKey("raw", e, t, {
            name: "RSA-OAEP",
            hash: {
                name: "SHA-1"
            }
        })
    })
}

function i(e, t, n, o, i) {
    var u = e.byteLength - (128 + 7 >> 3);
    return a(t, i).then(function(t) {
        return [r(JSON.stringify(o)), r(arrayBufferToString(t)), r(arrayBufferToString(n)), r(arrayBufferToString(e.slice(0, u))), r(arrayBufferToString(e.slice(u)))].join(".")
    })
}

function c(e, t, n, r) {
    var o = {
            kid: t.body.flx.jwk.kid || "",
            alg: "RSA-OAEP",
            enc: "A256GCM"
        },
        a = {
            data: e,
            context: n,
            index: r
        },
        c = crypto.getRandomValues(new Uint8Array(12));
    return u().then(function(e) {
        //a = payload, e = key, o = header, c = IV
        return s(a, e, o, c)
    }).then(function(e) {
        var n = l(e, 2);
        return i(n[0], n[1], c, o, t.body.flx.jwk || "")
    })
}

async function encryptCardData(card, keyId) {

    var splitkeyId = keyId.split('.');
    var header = JSON.parse(atob(splitkeyId[0]));
    var body = JSON.parse(atob(splitkeyId[1]));
    var decodedkeyId = {
        header: header,
        body: body,
        signature: splitkeyId[2]
    };



    var a = await c(card, decodedkeyId, keyId, 0);
    return a;
}